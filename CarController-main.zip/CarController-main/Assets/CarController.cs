using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace Fortem
{
    public class CarController : MonoBehaviour
    {
        public WheelCollider frontLeft, frontRight;
        public WheelCollider backLeft, backRight;
        public GameObject frontLeft_, frontRight_;
        public GameObject backLeft_, backRight_;
        public float vertical;
        public float horizontal;
        public float speed;

        private void Update()
        {
            vertical = Input.GetAxis("Vertical");
            horizontal = Input.GetAxis("Horizontal");
        }

        void FixedUpdate()
        {
            float motorTorque = speed * vertical;
            float steeringAngle = 45f * horizontal;

            frontLeft.steerAngle = steeringAngle;
            frontRight.steerAngle = steeringAngle;

            backLeft.motorTorque = motorTorque;
            backRight.motorTorque = motorTorque;

            frontLeft_.transform.localRotation = Quaternion.Euler(0, steeringAngle, 0);
            frontRight_.transform.localRotation = Quaternion.Euler(0, steeringAngle, 0);

            frontLeft_.transform.Rotate(backLeft.motorTorque, 0, 0);
            frontRight_.transform.Rotate(backRight.motorTorque, 0, 0);

            backLeft_.transform.Rotate(backLeft.motorTorque, 0, 0);
            backRight_.transform.Rotate(backRight.motorTorque, 0, 0);

            if (Input.GetKey(KeyCode.Space))
            {
                backLeft.motorTorque = 0;
                backRight.motorTorque = 0;
                backLeft.brakeTorque = 100000;
                backRight.brakeTorque = 100000;
            }
            else
            {
                backLeft.brakeTorque = 0;
                backRight.brakeTorque = 0;
            }
        }
    }
}